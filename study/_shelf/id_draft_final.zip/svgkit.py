# Minimal RFC7996-profile SVG emitter: presentation attributes only, no <style>/clip-path/<use>/metadata.
from xml.sax.saxutils import escape
NAVY="#14314f"; BLUE="#3a6ea5"; TEAL="#1b8f6a"; ORANGE="#c25a2b"; GRAY="#9aa4ac"; INK="#1f2a30"; LINE="#c9cfd4"; LIGHT="#e9edf0"
class SVG:
    def __init__(self,w,h): self.w=w; self.h=h; self.els=[]
    def rect(self,x,y,w,h,fill="none",stroke="none",sw=1,rx=0):
        r=f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"'
        if rx: r+=f' rx="{rx}"'
        self.els.append(r+'/>')
    def line(self,x1,y1,x2,y2,stroke=INK,sw=1,dash=None):
        d=f' stroke-dasharray="{dash}"' if dash else ''
        self.els.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{stroke}" stroke-width="{sw}"{d}/>')
    def text(self,x,y,s,size=11,fill=INK,anchor="start",weight="normal",style="normal",family="sans-serif"):
        self.els.append(f'<text x="{x:.1f}" y="{y:.1f}" font-family="{family}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" font-weight="{weight}" font-style="{style}">{escape(s)}</text>')
    def circle(self,cx,cy,r,fill="none",stroke=INK,sw=1):
        self.els.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    def poly(self,pts,fill="none",stroke=INK,sw=1):
        p=" ".join(f"{x:.1f},{y:.1f}" for x,y in pts)
        self.els.append(f'<polyline points="{p}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    def arrow(self,x1,y1,x2,y2,stroke=INK,sw=1.5):
        import math
        self.line(x1,y1,x2,y2,stroke,sw)
        # arrowhead: two barbs trailing BACK from the tip (x2,y2) toward (x1,y1)
        a=math.atan2(y2-y1,x2-x1); L=7.5; spread=0.5
        for da in (spread,-spread):
            bx=x2-L*math.cos(a+da); by=y2-L*math.sin(a+da)
            self.els.append(f'<line x1="{x2:.1f}" y1="{y2:.1f}" x2="{bx:.1f}" y2="{by:.1f}" stroke="{stroke}" stroke-width="{sw}"/>')
    def save(self,path):
        head=f'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" viewBox="0 0 {self.w} {self.h}" width="{self.w}" height="{self.h}">'
        open(path,"w").write(head+"".join(self.els)+"</svg>")
