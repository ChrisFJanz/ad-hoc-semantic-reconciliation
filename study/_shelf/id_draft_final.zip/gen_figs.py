from svgkit import *

def box(s,x,y,w,h,lines,fill="#ffffff",stroke=NAVY,sw=1.4,tsize=11,tfill=INK,bold0=False):
    s.rect(x,y,w,h,fill=fill,stroke=stroke,sw=sw,rx=6)
    n=len(lines); lh=15; ty=y+h/2-(n-1)*lh/2+4
    for i,ln in enumerate(lines):
        s.text(x+w/2,ty+i*lh,ln,size=tsize,anchor="middle",fill=tfill,
               weight=("bold" if (bold0 and i==0) else "normal"))

# All figures authored at width <= 560 so they fill the RFC text column
# without clipping or looking shifted.  Labels are kept off the arrows.

# ---- Fig 1: the object and its two operations ----
s=SVG(560,250)
box(s,8,44,96,48,["System A","data model"],fill=LIGHT,stroke=GRAY,tsize=11)
box(s,8,152,96,48,["System B","data model"],fill=LIGHT,stroke=GRAY,tsize=11)
box(s,150,36,158,60,["Semantic model A","ontology + lexicon,","pragmatics, provenance"],bold0=True,tsize=10)
box(s,150,148,158,60,["Semantic model B","ontology + lexicon,","pragmatics, provenance"],bold0=True,tsize=10)
box(s,398,84,156,74,["Correspondence","(aligned meaning);","data-model","translators generated"],stroke=TEAL,tsize=10)
# lift arrows (labels sit above the arrows, not on them)
s.arrow(104,68,148,68,stroke=BLUE,sw=1.6);  s.text(126,60,"lift",size=11,anchor="middle",fill=BLUE,weight="bold",style="italic")
s.arrow(104,176,148,176,stroke=BLUE,sw=1.6); s.text(126,168,"lift",size=11,anchor="middle",fill=BLUE,weight="bold",style="italic")
# reconciliation arrows converge on the Correspondence box; label sits in the gap between them
s.arrow(310,82,394,112,stroke=TEAL,sw=1.6)
s.arrow(310,180,394,140,stroke=TEAL,sw=1.6)
s.text(338,132,"reconciliation",size=11,anchor="middle",fill=TEAL,weight="bold",style="italic")
s.save("fig1-object.svg")

# ---- Fig 2: portability ladder ----
s=SVG(560,240)
rows=[("strong",1.00),("middle",0.87),("weak",0.73)]
x0,x1=118,500; y=44; bh=32; gap=20
s.text(x0-24,26,"comprehension (meaning score) on the hardest material",size=10,fill=GRAY,anchor="start")
for name,v in rows:
    s.text(x0-12,y+bh/2+4,name,size=12,anchor="end",fill=INK)
    s.rect(x0,y,x1-x0,bh,fill=LIGHT,rx=2)
    s.rect(x0,y,(x1-x0)*v,bh,fill=BLUE,rx=2)
    s.text(x0+(x1-x0)*v+8,y+bh/2+4,f"{v:.2f}",size=12,fill=NAVY,weight="bold")
    y+=bh+gap
s.line(x0,y+2,x1,y+2,stroke=LINE)
s.text(x0-24,y+22,"1.00 on routine material; holds across independent agent families.",size=10,fill=GRAY,anchor="start")
s.save("fig2-portability.svg")

# ---- Fig 3: one signal, three verdicts (pragmatics) ----
s=SVG(560,232)
box(s,8,94,120,52,["a rising","measurement"],fill=LIGHT,stroke=GRAY,tsize=11)
ctx=[("normal operation","act now (page)",ORANGE,34),
     ("in a maintenance window","benign (suppress)",TEAL,106),
     ("detector confidence low","watch",BLUE,178)]
for label,verdict,col,y in ctx:
    box(s,250,y,182,40,[label],fill="#ffffff",stroke=GRAY,tsize=10)
    box(s,452,y,100,40,[verdict],fill="#ffffff",stroke=col,tsize=10,tfill=col)
    s.arrow(130,120,248,y+20,stroke=col,sw=1.3)
    s.arrow(434,y+20,450,y+20,stroke=col,sw=1.3)
s.save("fig3-pragmatics.svg")

# ---- Fig 4: construct-then-bind (bars); x-axis baseline; no top gridline ----
s=SVG(560,290)
steps=[("no shared\nreference",0.20,ORANGE),("agents build\none",0.80,TEAL),("+ one virtual\nverification",0.90,TEAL)]
x0=81; base=232; H=170; bw=100; gapx=60
xend=x0+3*bw+2*gapx
# y axis + ticks
s.line(x0-22,base,x0-22,base-H,stroke=LINE)
for gv in (0.0,0.5,1.0):
    yy=base-H*gv; s.line(x0-26,yy,x0-22,yy,stroke=LINE); s.text(x0-32,yy+4,f"{gv:.1f}",size=9,anchor="end",fill=GRAY)
# x axis baseline
s.line(x0-22,base,xend,base,stroke=LINE)
s.text(x0-32,base-H-12,"resolved fraction (precision stays 1.00)",size=10,anchor="start",fill=GRAY)
x=x0
for lab,v,col in steps:
    s.rect(x,base-H*v,bw,H*v,fill=col,rx=2)
    s.text(x+bw/2,base-H*v-9,f"{v:.2f}",size=13,anchor="middle",fill=NAVY,weight="bold")
    for i,ln in enumerate(lab.split("\n")):
        s.text(x+bw/2,base+16+i*13,ln,size=10,anchor="middle",fill=INK)
    x+=bw+gapx
s.save("fig4-construct.svg")

# ---- Fig 5: N vs N^2 economics ----
s=SVG(560,300)
x0,y0=70,240; W,H=430,190
s.line(x0,y0,x0+W,y0,stroke=LINE); s.line(x0,y0,x0,y0-H,stroke=LINE)
Ns=list(range(2,9)); maxp=8*7//2
def px(n): return x0+ (n-2)/(8-2)*W
def py(v): return y0 - v/maxp*H
pw=[(px(n),py(n*(n-1)//2)) for n in Ns]
lin=[(px(n),py(n)) for n in Ns]
s.poly(pw,stroke=ORANGE,sw=2)
s.poly(lin,stroke=TEAL,sw=2)
for n in Ns: s.text(px(n),y0+16,str(n),size=9,anchor="middle",fill=GRAY)
s.text(x0+W/2,y0+34,"number of systems",size=10,anchor="middle",fill=GRAY)
s.text(px(8)-4,py(28)-6,"pairwise translators ~ N(N-1)/2",size=10,anchor="end",fill=ORANGE,weight="bold")
s.text(px(8)+6,py(8),"bindings to a shared reference ~ N",size=10,anchor="end",fill=TEAL,weight="bold")
s.text(x0-8,y0-H+2,"cognitive effort",size=10,anchor="start",fill=GRAY)
s.save("fig5-economics.svg")

# ---- Fig 6: the cognition spectrum (three cards) ----
AMBER="#c8922e"
s=SVG(560,236)
# top axis: cognition recedes, arrow points RIGHT (toward less cognition)
s.text(280,20,"cognition recedes",size=10,anchor="middle",fill=GRAY,style="italic")
s.arrow(150,30,412,30,stroke=GRAY,sw=1.3)
cards=[(6, TEAL, "Both cognitive",
        ["verify: mutual Q&A +","joint virtual experiments"],
        ["reconciliation ALWAYS","completes (autonomous,","verified)"]),
       (192, AMBER, "One side inert",
        ["verify: live agent runs","solo virtual experiments;","reference supplies facts"],
        ["mostly completes;","more is deferred"]),
       (378, ORANGE, "Cognition in overlay",
        ["verify: propose","candidates for an","external check"],
        ["no full autonomy;","external adjudication"])]
cw=176; cy=44; ch=176
for cx,col,title,verify,outcome in cards:
    s.rect(cx,cy,cw,ch,fill="#ffffff",stroke=col,sw=1.4,rx=6)
    s.rect(cx,cy,cw,26,fill=col,rx=6)          # title bar (rounded top)
    s.rect(cx,cy+14,cw,12,fill=col)            # square off the title bar's bottom
    s.text(cx+cw/2,cy+18,title,size=11,anchor="middle",fill="#ffffff",weight="bold")
    ty=cy+46
    for ln in verify:
        s.text(cx+12,ty,ln,size=9,anchor="start",fill=INK); ty+=14
    dy=cy+100
    s.line(cx+12,dy,cx+cw-12,dy,stroke=LINE)   # divider
    oy=dy+22                                    # clear gap below the divider
    for ln in outcome:
        s.text(cx+12,oy,ln,size=9,anchor="start",fill=col,weight="bold"); oy+=14
s.save("fig6-spectrum.svg")

print("built 6 figures (fig1-fig6)")
